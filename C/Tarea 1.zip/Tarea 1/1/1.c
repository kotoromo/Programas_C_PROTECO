//Programa que calcule el numero binario de un numero decimal entero introducido por el usuario.
//El programa debe mostrar el binario, su complemento a 1 y su complemento a 2.

//Lo intente pero no pude :(