//Calculadorea de complejos

/*Se me ocurre como pero creo que requiere de punteros, pues se debe tener un string con el complejo a operar. 
En ese string se debe separar en secciones: una de complejos y otra de reales. Se operan por individual o se realizan las
conversiones necesarias para realizar la operacion requerida. */